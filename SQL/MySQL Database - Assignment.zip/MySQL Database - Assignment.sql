##Create a database named people_education.
create database people_education;

##Show that the database has been created.
show databases;

Use people_education;

-- Creating table people_info with name, age, high school attended, and height. 
Create table people_info (
	Name varchar(20),
	Age int,
	High_school_attended varchar(100),
	Height float
);
-- Creating table school_info with school name, zip code. 
Create table school_info (
school_name varchar(100),		
 zip_code int
);

-- Creating table school_mascot with school name, the school mascot. 
Create table school_mascot (
school_name varchar(100),
the_school_mascot varchar(100)
);

-- Show all tables using the show tables; command.
Show tables;

-- Delete the school_mascot table.
Drop table school_mascot;

-- 	Inserting data into the table people_info
INSERT INTO people_info (name, age, high_school_attended, height) VALUES
('Chris Josh', 35, 'Sagarmatha High school', 1.05),
('Molly Smith', 31, 'SunRise High school', 1.18),
('Alice Brown', 19, 'Pegasus High school', 1.44),
('Janvi Josh', 23, 'Church High school', 1.56);

-- 	Inserting data into the table School_info
INSERT INTO School_info (school_name,zip_code)VALUES
("John fisher school", 00011),
("Pegasus school",00012), 
("SunRise English school",00013),
("Janata School",00014)
;