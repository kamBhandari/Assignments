use hero;
select * from heroes_information;

#1) Start by querying all of the data from heroes_information if the Race has an average weight of over 400.
SELECT *, AVG(weight) AS avg_weight
FROM heroes_information
GROUP BY race
HAVING avg_weight > 400;
 
#2) Create a temporary table for this result called bigs.
CREATE TEMPORARY TABLE bigs AS
SELECT *
FROM heroes_information
WHERE race IN (
  SELECT race
  FROM heroes_information
  GROUP BY race
  HAVING AVG(weight) > 400
);
 
#3) Select all columns and rows from that temporary table.
SELECT * FROM bigs;
 
#4) Write a new query that creates a view that selects the data if the publisher is Marvel Comics and if their height is above the average height.Bring that view up.
 CREATE VIEW marvel_heroes_above_average_height AS
SELECT *
FROM heroes_information
WHERE publisher = 'Marvel Comics' AND height > (
  SELECT AVG(height)
  FROM heroes_information
  WHERE publisher = 'Marvel Comics'
);

#view query
SELECT * FROM marvel_heroes_above_average_height;

#5) Now add an index to the heroes_information table on the name and Race columns.
 CREATE INDEX idx_name_race ON heroes_information (name, Race);
 
#6) Finally, create a stored procedure that selects all the data from heroes_information if they are from DC. Call it all_dc_rows.
delimiter $$
CREATE PROCEDURE all_dc_rows()
BEGIN
  SELECT * FROM heroes_information
  WHERE publisher = 'DC';
  END $$
  
  #Call the stored procedure
CALL all_dc_rows();