use hero_hero_battle;

select * from heroes_information;

-- 1) Take hero_battles and do a left join on heroes_information on the name columns. Select all columns. 
-- select *from heroes_information left join hero_battles on hero_battles.MyUnknownColumn = heroes_information.MyUnknownColumn;
 SELECT * FROM hero_battles 
 LEFT JOIN heroes_information 
 ON hero_battles.MyUnknownColumn = heroes_information.MyUnknownColumn;

-- 2) Take super_hero_powers and do a right join with hero_battles on the name columns. Note that the name column is hero_names on the super_hero_powers table. 
 SELECT * FROM shero_battles 
 RIGHT JOIN super_hero_powers 
 ON super_hero_powers.hero_names = hero_battles.name;
 
-- 3) Select all the female heroes from heroes_information and stack that name result on top of all the heroes who have accelerated healing from the super_hero_powers table. Only return the name columns.
SELECT name FROM heroes_information
 WHERE gender= "female"
 UNION 
SELECT hero_names AS name
FROM super_hero_powers
WHERE '%accelerated healing%'=True;