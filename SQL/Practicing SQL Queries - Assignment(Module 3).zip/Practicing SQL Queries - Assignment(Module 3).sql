
-- Start by returning all rows and columns from the hero_battles data table.
SELECT * FROM hero_battles;

--  Now, return only the first 5 rows instead of returning all rows. 
Select * from hero_battles limit 5;

-- Select only the date column from the hero_battles table. But use an alias to change the name of the date column to timestamp. 
Select date as Timestamp from hero_battles;

-- Finally, select the first 4 rows of the hero_battles table but alias the table name to hb. And only select the name and num_enemies columns and rename them respectively as hero_name and number_of_enemies. 
Select name as hero_name , num_enemies as number_of_enemies from hero_battles as hb limit 4;



